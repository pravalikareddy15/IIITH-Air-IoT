/*
 * scrc_constant.h
 *
 *  Created on: 16-Oct-2020
 *      Author: BSRC-Sam
 *  last update :22-08-2023
 *      Author : SCRC-Sasidhar
 */

#ifndef INCLUDE_SCRC_CONSTANT_H_
#define INCLUDE_SCRC_CONSTANT_H_

/*
 * uncomment to print debug statements
 */
#define DEBUG false

/*
 * node type
 */

#define NT_POLLUTION
//#define NT_WATER
#define led_pin 33
/*
 * Controller type
 */
#define CT_ESP_8266
//#define CT_ESP_32

/*
 * uncomment to publish to om2m
 */
#define PUB_OM2M

/*
 * uncomment to publish to ThingSpeak
 */
#define PUB_THINGSPEAK

/*
 * time interval in milliseconds
 */
#define TIME_INTERVAL_15_SEC  15000

#define TIME_INTERVAL_1_HR    3600000             //1 * 60* 60 * 1000

#define TIME_INTERVAL_10_MIN  600000             //10*60 * 1000
#define TIME_INTERVAL_1_MIN  60000             //10*60 * 1000

// count of sensor reading in 10 min @ 15 sec, i.e., 4 reading per min, (40)
#define PRIMARY_BUF_COUNT  40

// count of 10 min avg sensor reading in 1 days, i.e., 6 reading per 1 hour, (144 reading)
#define SEC_BUF_COUNT  100

// #define NODE_1     //GuestHouse 
// #define NODE_2     //kadhamaba
// #define NODE_3     // Palash Nivas
// #define NODE_4     //Main gate
// #define NODE_5     //Library
// #define NODE_6     //FSQ
// #define NODE_7     //Football
// #define NODE_8     //T-hub
// #define NODE_9     //Ph-3
#define NODE_10    //ph-4

/*
 * WiFi credentials
 * Thingspeak Credentials
 * Https  define 
//  */

  // #define MAIN_SSID "JioFi3_259D0E" // air-iot wifi  
  // #define MAIN_PASS "k61m12m0u5"

  // #define MAIN_SSID "JioFi3_259D0E" // air-iot wifi  
  // #define MAIN_PASS "k61m12m0u5"

#ifdef NODE_1 // Guest house

  // #define MAIN_SSID "SAHANA-1"  
  // #define MAIN_PASS "0BEEF6590BEEF6590BEEF65926"
  
  #define MAIN_SSID "TP-Link_1E6D"//main
  #define MAIN_PASS "18228953"

  // #define MAIN_SSID "JioFi3_259D0E" // air-iot wifi  
  // #define MAIN_PASS "k61m12m0u5"

  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-SN00-00"
  #define OM2M_DATA_CONT  "AQ-SN00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-SN00-00\", \"AQ-V4.1.0\"]"
  
  #define myChannel 885762;
  #define writeAPIKey  "VWMXNW6NJOQVVVI3"
 
  const float m_pm25 = 1.4331251;
  const float c_pm25 = 4.742084470783219;
  const float m_pm10 = 1.07096329;
  const float c_pm10 = 7.293950141159094;
  const float m_db = 1.11269314;
  const float c_db = -17.7747384;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_2 //Khdhamaba Nivas

  #define MAIN_SSID "TP-Link_5674"
  #define MAIN_PASS "49508680"
  
  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-KN00-00"
  #define OM2M_DATA_CONT  "AQ-KN00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-KN00-00\", \"AQ-V4.1.0\"]"

  #define myChannel 937750;
  #define writeAPIKey  "W9L6N34IC1MNE7HN"

  const float m_pm25 = 1.36744485;
  const float c_pm25 = 2.4886480524120245;
  const float m_pm10 = 1.10628045;
  const float c_pm10 = 5.271731126511618;
  const float m_db = 1.15669996;
  const float c_db = -17.92279091;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_3 //Palash Nivas

  #define MAIN_SSID "TP-Link_3934"  
  #define MAIN_PASS "wdsdtumt9r"


  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-PL00-00"
  #define OM2M_DATA_CONT  "AQ-PL00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-PL00-00\", \"AQ-V4.1.0\"]"

  #define myChannel 938513;
  #define writeAPIKey  "SP2M6BRIC92GPIM8"

  const float m_pm25 = 1.33411918;
  const float c_pm25 = 4.9818905419675446;
  const float m_pm10 = 0.94466114;
  const float c_pm10 = 9.813320798517374;
  const float m_db = 1.19083974;
  const float c_db = -19.38941144;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_4 // Main Gate 

  #define MAIN_SSID "TP-Link_0EC8"  
  #define MAIN_PASS "78726598" 

  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-MG00-00"
  #define OM2M_DATA_CONT  "AQ-MG00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-MG00-00\", \"AQ-V4.1.0\"]"

  #define myChannel 939888;
  #define writeAPIKey  "WDVVTDSX00XL5V05"

  const float m_pm25 = 1.35046421;
  const float c_pm25 = 4.6615967142956904;
  const float m_pm10 = 1.05606463;
  const float c_pm10 = 6.583038399911835;
  const float m_db = 1.02441544;
  const float c_db = -10.72394619;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_5 //library

  // #define MAIN_SSID "esw-m19@iiith"         
  // #define MAIN_PASS "e5W-eMai@3!20hOct"

  #define MAIN_SSID "REVANTH"         
  #define MAIN_PASS "12345678"

  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-VN90-00"
  #define OM2M_DATA_CONT  "AQ-VN90-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-VN90-00\", \"AQ-V4.1.0\"]"

  #define myChannel 944545;
  #define writeAPIKey  "LH08QHJZ82YEXWUL"

  const float m_pm25 = 1.48438163;
  const float c_pm25 = 1.8241161013490128;
  const float m_pm10 = 1.05706898;
  const float c_pm10 = 7.440667226537904;
  const float m_db = 1.00015022;
  const float c_db = -8.563727760751703;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_6//Anand Nivas
  
  #define MAIN_SSID "TP-Link_B2D2"
  #define MAIN_PASS "94057867" 

  #define HTTPS     false   
  #define OM2M_NODE_ID   "AQ-AN00-00"
  #define OM2M_DATA_CONT  "AQ-AN00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-AN00-00\", \"AQ-V4.1.0\"]"

  #define myChannel 944798;
  #define writeAPIKey  "IGN8L3ACV8PWB9YK"

  const float m_pm25 = 1.34617992;
  const float c_pm25 = 1.9368249340128472;
  const float m_pm10 = 1.05324581;
  const float c_pm10 = 6.019561475673761;
  const float m_db = 1.1723007;
  const float c_db = -16.73790347404703;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_7 //Food Ball Ground

  // #define MAIN_SSID "esw-m19@iiith"         
  // #define MAIN_PASS "e5W-eMai@3!20hOct"

  // #define MAIN_SSID "TP-Link_BC75"       
  // #define MAIN_PASS "67653416"


  #define MAIN_SSID "myssid"       
  #define MAIN_PASS "passwordy"


  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-FG00-00"
  #define OM2M_DATA_CONT  "AQ-FG00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-FG00-00\", \"AQ-V4.1.0\"]"

  #define myChannel 945028;
  #define writeAPIKey  "4PCMYWJ8XUHUSHUW"

  const float m_pm25 = 1.28306944;
  const float c_pm25 = 2.426491433308307;
  const float m_pm10 = 1.02844443;
  const float c_pm10 = 5.044161995868912;
  const float m_db = 0.98911796;
  const float c_db = -7.851738336903324;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_8  // T-hub

  #define MAIN_SSID "esw-m19@iiith"         
  #define MAIN_PASS "e5W-eMai@3!20hOct"

  // #define HTTPS     false
  // #define OM2M_NODE_ID   "AQ-KH00-00"
  // #define OM2M_DATA_CONT  "AQ-KH00-00/Data"
  // #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.0.0\", \"AQ-KH00-00\", \"AQ-V4.0.0\"]"

  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-TH00-00"
  #define OM2M_DATA_CONT  "AQ-TH00-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-TH00-00\", \"AQ-V4.1.0\"]"

  #define myChannel 947311;
  #define writeAPIKey  "1CLG8H9WWR7Y7HGF"

  const float m_pm25 = 1.29998966;
  const float c_pm25 = 3.189609921191831;
  const float m_pm10 = 1.00412213;
  const float c_pm10 = 6.183487645723254;
  const float m_db = 1.18603921;
  const float c_db = -16.831304941086657;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_9  //Pump House -3

  #define MAIN_SSID "JioFi3_B51E5B" 
  #define MAIN_PASS "P1m9h0u53@3"

  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-PH03-00"
  #define OM2M_DATA_CONT  "AQ-PH03-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-PH03-00\", \"AQ-V4.1.0\"]"

  #define myChannel 1099442;
  #define writeAPIKey  "UUESWH1NUKNQXM47"

  const float m_pm25 = 1.39953637;
  const float c_pm25 = 1.0139899351202786;
  const float m_pm10 = 1.05333699;
  const float c_pm10 = 5.398502802863497;
  const float m_db = 1.00015022;
  const float c_db = -8.563727760751703;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;

#endif

#ifdef NODE_10  //ph-4

  // #define HTTPS     true
  // #define OM2M_NODE_ID   "AQ-BN00-00"
  // #define OM2M_DATA_CONT  "AQ-BN00-00/Data"
  // #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.0.0\", \"AQ-BN00-00\", \"AQ-V4.0.0\"]"
  
  // #define myChannel 928486;
  // #define writeAPIKey  "PSKWJ8GP0HS55WL6"

  #define MAIN_SSID "TP-Link_5470"  
  #define MAIN_PASS "32262728"

  #define HTTPS     false
  #define OM2M_NODE_ID   "AQ-PH04-00"
  #define OM2M_DATA_CONT  "AQ-PH04-00/Data"
  #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.1.0\", \"AQ-PH04-00\", \"AQ-V4.1.0\"]"
  
  #define myChannel 2266784;
  #define writeAPIKey  "0T3RBYHFS9G0JWEJ"

  const float m_pm25 = 1.4122315;
  const float c_pm25 = 0.7362176533182279;
  const float m_pm10 = 1.08695388;
  const float c_pm10 = 4.622703747648451;
  const float m_db = 0.98911796;
  const float c_db = -7.851738336903324;
  const float m_temp = 1.0;
  const float c_temp = 0.0;
  const float m_rh = 1.0;
  const float c_rh = 0.0;


#endif


#define RETRY_WIFI_INTERVAL 60000  // in ms (1 min)
#define RETRY_WIFI_FACTOR 2     //multiplication factor user to increment the retry interval

#define STARTUP_WIFI_TIMEOUT  60000   //WiFi connection Timeout
#define STARTUP_WIFI_RETRY_DELAY 100  // WiFi reconnection delay

#define Timeoffset 19800

#define Reading_10min 2

#define MAX_STRING_LEN 255

/*
 * OneM2M connection details
 */
#define CSE_IP      "onem2m.iiit.ac.in"
#define OM2M_ORGIN    "AirPoll@20:22uHt@Sas"
#define CSE_PORT    443
#define FINGER_PRINT  "10 3D D5 4E B1 47 DB 4B 5C B0 89 08 41 A7 A4 14 87 10 7F E8"
#define OM2M_MN       "/~/in-cse/in-name/"
#define OM2M_AE       "AE-AQ"

// #define OM2M_NODE_ID   "AQ-SN00-00"
// #define OM2M_DATA_CONT  "AQ-SN00-00/Data"
// #define OM2M_DATA_LBL   "[\"AE-AQ\", \"V4.0.0\", \"AQ-SN00-00\", \"AQ-V4.0.0\"]"
// dev-server
// #define CSE_IP      "dev-onem2m.iiit.ac.in"
// #define OM2M_ORGIN    "Tue_20_12_22:Tue_20_12_22"

/*
 Debug Function
 */
#if DEBUG
#define debug_info(fmt, ...) Serial.print(fmt, ##__VA_ARGS__)
#define debug_err(fmt, ...) Serial.print(fmt, ##__VA_ARGS__)
#else
  #define debug_info(fmt, ...) ((void)0)
  #define debug_err(fmt, ...) ((void)0)
#endif

/*
 * Error Handling Codes
 */
#define E_OM2M_NW -101
#define E_OM2M_CONNECT -102
#define E_OM2M_CONNECTION -103
#define E_OM2M_NO_RESPONSE -104
#define E_OM2M_EMPTY_RESPONSE -105

#define E_THINGSPEAK_NW -201
#define E_THINGSPEAK_CONNECT -202
#define E_THINGSPEAK_CONNECTION -203
#define E_THINGSPEAK_NO_RESPONSE -204
#define E_THINGSPEAK_EMPTY_RESPONSE -205

/*
 * Success Codes
 */
#define SUCCESS_OM2M 400
#define SUCCESS_THINGSPEAK 800

#endif /* INCLUDE_SCRC_CONSTANT_H_ */
