// // #define SoundSensorPin A0  // ESP8266 uses A0 for analog input //esp8266
// #define SoundSensorPin 36  // GPIO pin for sound sensor   // esp32
// #define VREF  3.3  // Voltage reference for ESP8266 (operating voltage)

// float voltageValue, dbValue;

// void hw_setup_noise() {
//   Serial.begin(9600);  // Initialize serial communication
//   pinMode(SoundSensorPin, INPUT);  // Set sound sensor pin as input
//   delay(3000);                     // Delay for system stability
// }

// void sound_loop() {
//   sound_loop();  // Read sound levels
// }

//   voltageValue = analogRead(SoundSensorPin) / 1024.0 * VREF;
//   dbValue = voltageValue * 50.0;
//   Serial.print("Sound Level: ");
//   Serial.print(dbValue, 1);
//   Serial.println(" dBA");
// }





#ifndef SCRC_NOISE_H
#define SCRC_NOISE_H

#define SoundSensorPin 36  // ESP32 ADC pin for the sound sensor
#define VREF 3.3  // Reference voltage for ADC

void hw_setup_noise();
void hw_read_noise(float *dbValue, float *dbValue_cal);
void sound_loop();

#endif
