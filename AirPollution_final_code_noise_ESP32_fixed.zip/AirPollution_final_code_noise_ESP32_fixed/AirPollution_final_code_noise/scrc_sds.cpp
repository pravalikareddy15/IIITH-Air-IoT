#include <SDS011.h>
#include <SoftwareSerial.h>
#include "Arduino.h"
#include "scrc_sds.h"
#include "scrc_constants.h"

#define MIN_READING 0.1
#define MAX_READING 999.9
#define node_RX 3  // Define ESP32 RX pin for SDS011
#define node_TX 17  // Define ESP32 TX pin for SDS011

SDS011 my_sds;
SoftwareSerial sdsSerial(node_RX, node_TX);  // Create SoftwareSerial object
float p25, p10;

void hw_setup_sds() {
    Serial.begin(115200);  // Debugging
    sdsSerial.begin(9600);  // Start SoftwareSerial for SDS011
    my_sds.begin(node_RX, node_TX);  // Use SoftwareSerial pins for SDS011
    Serial.println("SDS011 sensor initialized");
}

void hw_read_sds(float *buf_pm25, float *buf_pm25cal , float *buf_pm10, float *buf_pm10cal) {
    int error = my_sds.read(&p25, &p10);  // Fix: Pass pointers instead of values
    
    if (error == 0) {  // Read successful
        *buf_pm25 = p25;
        *buf_pm10 = p10;
        
        // Apply calibration (Ensure `m_pm25`, `c_pm25`, `m_pm10`, `c_pm10` are defined in constants)
        *buf_pm25cal = (m_pm25 * p25) + c_pm25;
        *buf_pm10cal = (m_pm10 * p10) + c_pm10;

        // Validate readings
        if (*buf_pm25 < MIN_READING || *buf_pm25 > MAX_READING) *buf_pm25 = NAN;
        if (*buf_pm10 < MIN_READING || *buf_pm10 > MAX_READING) *buf_pm10 = NAN;

        // Print values
        Serial.print("PM2.5: "); Serial.println(*buf_pm25);
        Serial.print("PM10: "); Serial.println(*buf_pm10);
        Serial.print("PM2.5 Calibrated: "); Serial.println(*buf_pm25cal);
        Serial.print("PM10 Calibrated: "); Serial.println(*buf_pm10cal);
    } else {
        Serial.println("SDS011 Read Error");
    }
}
